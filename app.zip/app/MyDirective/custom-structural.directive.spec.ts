import { CustomStructuralDirective } from './custom-structural.directive';

describe('CustomStructuralDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomStructuralDirective();
    expect(directive).toBeTruthy();
  });
});
