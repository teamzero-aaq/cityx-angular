export class user {
    username?: string
    password?: string
    userid?: number
}
