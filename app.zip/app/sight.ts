export class Sight {
    id?: number;
    name?: string
    imgUrl?: string
    description?: string
    address?: string
    city?: string
    price?: number   
}