import { Component, OnInit } from '@angular/core';
import { Sight } from 'src/app/sight';

@Component({
  selector: 'app-show-sight',
  templateUrl: './show-sight.component.html',
  styleUrls: ['./show-sight.component.css'],
})
export class ShowSightComponent implements OnInit {
  sights: Sight[];
  localItems: string;
  constructor() {
    this.localItems = localStorage.getItem('sights');
    if (this.localItems == null) {
      this.sights = [
        {
          name: 'Whitehouse',
          imgUrl:
            'https://images.unsplash.com/photo-1494526585095-c41746248156?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
          description: 'a great place',
          address: 'near xyz',
          city: 'Mumbai',
          price: 2000,
        },
        {
          name: 'Casa Palmera',
          imgUrl:
            'https://lh3.googleusercontent.com/proxy/Cfqc2-peOGJvjNZgaTBwCX-KlOpnkbQkXA3TuoAIOdSHGSwu6w1SpQ5u_r2Di6mEMoa5-n5WgpEclgF-4RWcVeiVMuHDQL0zQbAZqeLyS4E2SrsQY5jVhf0DtTJeMuhvJ2r7yZWIjPkqaUpjU31a812MwpPvkQ=w296-h202-n-k-rw-no-v1',
          description: 'massive swimming pool - lush green lawns',
          address: 'near xyz',
          city: 'Thane',
          price: 3000,
        },
        {
          name: 'Villa Norway',
          imgUrl:
            'https://cf.bstatic.com/xdata/images/hotel/max1024x768/284751571.webp?k=cbca86df09761b498041c13d65e34ced803ce796efa0f23a428a156cae7ea248&o=',
          description: 'eaturing air-conditioned accommodation',
          address: 'near xyz',
          city: 'Gujarat',
          price: 1200,
        },
      ];
    }
    else {
      this.sights = JSON.parse(this.localItems);
    }
    
  }

  ngOnInit(): void { }
  
  AddSight(sight: Sight) {
    console.log(sight);
    this.sights.push(sight);
    localStorage.setItem('sights', JSON.stringify(this.sights));
  }
}
